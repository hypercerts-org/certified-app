# Schema Reference

> This file is auto-generated from lexicon definitions.
> Do not edit manually.

## Hypercerts Lexicons

Hypercerts-specific lexicons for tracking impact work and claims.

### `org.hypercerts.authWrite`

**Title:** Manage your Hypercerts data

**Detail:** Create, edit, and delete your Hypercerts records (impact claims, evaluations, funding, and related data).

**Resource:** `repo`

**Collections:** `org.hypercerts.claim.activity`, `org.hypercerts.claim.contribution`, `org.hypercerts.claim.contributorInformation`, `org.hypercerts.claim.rights`, `org.hypercerts.collection`, `org.hypercerts.context.acknowledgement`, `org.hypercerts.context.attachment`, `org.hypercerts.context.evaluation`, `org.hypercerts.context.measurement`, `org.hypercerts.entity.feature`, `org.hypercerts.funding.receipt`, `org.hypercerts.vocab.tag`, `org.hypercerts.workscope.tag`

**Actions:** `create`, `update`, `delete`

---

### `org.hypercerts.claim.activity`

**Description:** A hypercert record tracking impact work.

**Key:** `any`

#### Properties

| Property                 | Type       | Required | Description                                                                                                                                                                                                                                                                                                                                                                                       | Comments                           |
| ------------------------ | ---------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------- |
| `title`                  | `string`   | ✅       | Display title summarizing the impact work (e.g. 'Reforestation in Amazon Basin 2024')                                                                                                                                                                                                                                                                                                             | maxLength: 256                     |
| `shortDescription`       | `string`   | ✅       | Short summary of this activity claim, suitable for previews and list views. Rich text annotations may be provided via `shortDescriptionFacets`.                                                                                                                                                                                                                                                   | maxLength: 3000, maxGraphemes: 300 |
| `shortDescriptionFacets` | `ref[]`    | ❌       | Rich text annotations for `shortDescription` (mentions, URLs, hashtags, etc).                                                                                                                                                                                                                                                                                                                     |                                    |
| `description`            | `union`    | ❌       | Long-form description of the activity. An inline string for plain text or markdown, a Leaflet linear document for rich-text content, or a strong reference to an external description record.                                                                                                                                                                                                     |                                    |
| `langs`                  | `string[]` | ❌       | Human language(s) of this record's text fields, as BCP-47 language tags (e.g. 'es', 'pt-BR'); up to three for mixed-language text. Set by the writing app from the text the author wrote, with the author able to correct it; never from the interface language or a profile preference alone. A hint for readers, not a guarantee: consumers must not hide a record because it lacks this field. | maxLength: 3                       |
| `image`                  | `union`    | ❌       | The hypercert visual representation as a URI or image blob.                                                                                                                                                                                                                                                                                                                                       |                                    |
| `contributors`           | `ref[]`    | ❌       | An array of contributor objects, each containing contributor information, weight, and contribution details.                                                                                                                                                                                                                                                                                       |                                    |
| `workScope`              | `union`    | ❌       | Work scope definition. A CEL expression for structured, machine-evaluable scopes or a free-form string for simple and legacy scopes.                                                                                                                                                                                                                                                              |                                    |
| `startDate`              | `string`   | ❌       | When the work began                                                                                                                                                                                                                                                                                                                                                                               |                                    |
| `endDate`                | `string`   | ❌       | When the work ended                                                                                                                                                                                                                                                                                                                                                                               |                                    |
| `locations`              | `ref[]`    | ❌       | An array of strong references to the location where activity was performed. The record referenced must conform with the lexicon app.certified.location.                                                                                                                                                                                                                                           | maxLength: 1000                    |
| `rights`                 | `ref`      | ❌       | A strong reference to the rights that this hypercert has. The record referenced must conform with the lexicon org.hypercerts.claim.rights.                                                                                                                                                                                                                                                        |                                    |
| `createdAt`              | `string`   | ✅       | Client-declared timestamp when this record was originally created                                                                                                                                                                                                                                                                                                                                 |                                    |
| `signatures`             | `ref`      | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                                                                                                                             |                                    |

#### Defs

##### `org.hypercerts.claim.activity#contributor`

A contributor to the activity, with identity, weight, and contribution details.

| Property              | Type     | Required | Description                                                                                                                                                                                                                                                                                       | Comments       |
| --------------------- | -------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------- |
| `contributorIdentity` | `union`  | ✅       | Inline contributor identity object with an identity string (DID or identifier) via org.hypercerts.claim.activity#contributorIdentity, or a strong reference to a contributor information record. The record referenced must conform with the lexicon org.hypercerts.claim.contributorInformation. |                |
| `contributionWeight`  | `string` | ❌       | The relative weight/importance of this contribution (stored as a string to avoid float precision issues). Must be a positive numeric value. Weights do not need to sum to a specific total; normalization can be performed by the consuming application as needed.                                | maxLength: 100 |
| `contributionDetails` | `union`  | ❌       | Inline contribution role object with a role string via org.hypercerts.claim.activity#contributorRole, or a strong reference to a contribution details record. The record referenced must conform with the lexicon org.hypercerts.claim.contribution.                                              |                |

##### `org.hypercerts.claim.activity#contributorIdentity`

Contributor information as a string (DID or identifier).

| Property   | Type     | Required | Description                                          | Comments                           |
| ---------- | -------- | -------- | ---------------------------------------------------- | ---------------------------------- |
| `identity` | `string` | ✅       | The contributor identity string (DID or identifier). | maxLength: 1000, maxGraphemes: 100 |

##### `org.hypercerts.claim.activity#contributorRole`

Contribution details as a string.

| Property | Type     | Required | Description                       | Comments                           |
| -------- | -------- | -------- | --------------------------------- | ---------------------------------- |
| `role`   | `string` | ✅       | The contribution role or details. | maxLength: 1000, maxGraphemes: 100 |

##### `org.hypercerts.claim.activity#workScopeString`

A free-form string describing the work scope for simple or legacy scopes.

| Property | Type     | Required | Description                        | Comments                             |
| -------- | -------- | -------- | ---------------------------------- | ------------------------------------ |
| `scope`  | `string` | ✅       | The work scope description string. | maxLength: 10000, maxGraphemes: 1000 |

---

### `org.hypercerts.claim.contribution`

**Description:** Details about a specific contribution including role, description, and timeframe.

**Key:** `tid`

#### Properties

| Property                  | Type     | Required | Description                                                                           | Comments                             |
| ------------------------- | -------- | -------- | ------------------------------------------------------------------------------------- | ------------------------------------ |
| `role`                    | `string` | ❌       | Role or title of the contributor.                                                     | maxLength: 100                       |
| `contributionDescription` | `string` | ❌       | Description of what the contribution concretely involved.                             | maxLength: 10000, maxGraphemes: 1000 |
| `startDate`               | `string` | ❌       | When this contribution started. Should fall within the parent hypercert's timeframe.  |                                      |
| `endDate`                 | `string` | ❌       | When this contribution finished. Should fall within the parent hypercert's timeframe. |                                      |
| `createdAt`               | `string` | ✅       | Client-declared timestamp when this record was originally created.                    |                                      |
| `signatures`              | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                 |                                      |

---

### `org.hypercerts.claim.contributorInformation`

**Description:** Contributor information including identifier, display name, and image.

**Key:** `tid`

#### Properties

| Property      | Type     | Required | Description                                                           | Comments        |
| ------------- | -------- | -------- | --------------------------------------------------------------------- | --------------- |
| `identifier`  | `string` | ❌       | DID (did:plc:...) or URI to a social profile of the contributor.      | maxLength: 2048 |
| `displayName` | `string` | ❌       | Human-readable name for the contributor as it should appear in UI.    | maxLength: 100  |
| `image`       | `union`  | ❌       | The contributor visual representation as a URI or image blob.         |                 |
| `createdAt`   | `string` | ✅       | Client-declared timestamp when this record was originally created.    |                 |
| `signatures`  | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content. |                 |

---

### `org.hypercerts.claim.rights`

**Description:** Describes the rights that a contributor and/or an owner has, such as whether the hypercert can be sold, transferred, and under what conditions.

**Key:** `tid`

#### Properties

| Property            | Type     | Required | Description                                                                                            | Comments                             |
| ------------------- | -------- | -------- | ------------------------------------------------------------------------------------------------------ | ------------------------------------ |
| `rightsName`        | `string` | ✅       | Human-readable name for these rights (e.g. 'All Rights Reserved', 'CC BY-SA 4.0')                      | maxLength: 100                       |
| `rightsType`        | `string` | ✅       | Short identifier code for this rights type (e.g. 'ARR', 'CC-BY-SA') to facilitate filtering and search | maxLength: 10                        |
| `rightsDescription` | `string` | ✅       | Detailed explanation of the rights holders' permissions, restrictions, and conditions                  | maxLength: 10000, maxGraphemes: 1000 |
| `attachment`        | `union`  | ❌       | An attachment to define the rights further, e.g. a legal document.                                     |                                      |
| `createdAt`         | `string` | ✅       | Client-declared timestamp when this record was originally created                                      |                                      |
| `signatures`        | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                                  |                                      |

---

### `org.hypercerts.collection`

**Description:** A collection/group of items (activities and/or other collections). Collections support recursive nesting.

**Key:** `tid`

#### Properties

| Property                 | Type       | Required | Description                                                                                                                                                                                                                                                                                                                                                                                       | Comments                                                                    |
| ------------------------ | ---------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| `type`                   | `string`   | ❌       | The type of this collection. Values beyond the known set are permitted.                                                                                                                                                                                                                                                                                                                           | maxLength: 64, Known values: `favorites`, `project`, `portfolio`, `program` |
| `title`                  | `string`   | ✅       | Display name for this collection (e.g. 'Q1 2025 Impact Projects')                                                                                                                                                                                                                                                                                                                                 | maxLength: 800, maxGraphemes: 80                                            |
| `shortDescription`       | `string`   | ❌       | Short summary of this collection, suitable for previews and list views. Rich text annotations may be provided via `shortDescriptionFacets`.                                                                                                                                                                                                                                                       | maxLength: 3000, maxGraphemes: 300                                          |
| `shortDescriptionFacets` | `ref[]`    | ❌       | Rich text annotations for `shortDescription` (mentions, URLs, hashtags, etc).                                                                                                                                                                                                                                                                                                                     |                                                                             |
| `description`            | `union`    | ❌       | Long-form description of the collection. An inline string for plain text or markdown, a Leaflet linear document for rich-text content, or a strong reference to an external description record.                                                                                                                                                                                                   |                                                                             |
| `langs`                  | `string[]` | ❌       | Human language(s) of this record's text fields, as BCP-47 language tags (e.g. 'es', 'pt-BR'); up to three for mixed-language text. Set by the writing app from the text the author wrote, with the author able to correct it; never from the interface language or a profile preference alone. A hint for readers, not a guarantee: consumers must not hide a record because it lacks this field. | maxLength: 3                                                                |
| `avatar`                 | `union`    | ❌       | The collection's avatar/profile image as a URI or image blob.                                                                                                                                                                                                                                                                                                                                     |                                                                             |
| `banner`                 | `union`    | ❌       | Larger horizontal image to display behind the collection view.                                                                                                                                                                                                                                                                                                                                    |                                                                             |
| `items`                  | `ref[]`    | ❌       | Array of items in this collection with optional weights.                                                                                                                                                                                                                                                                                                                                          | maxLength: 1000                                                             |
| `location`               | `ref`      | ❌       | A strong reference to the location where this collection's activities were performed. The record referenced must conform with the lexicon app.certified.location.                                                                                                                                                                                                                                 |                                                                             |
| `tags`                   | `ref[]`    | ❌       | References to org.hypercerts.vocab.tag records classifying this record. All listed tags apply simultaneously (logical AND); the array carries no ordering, weighting, negation, inheritance, or rule logic, and never will — any future expression logic must arrive as a new field and must never reinterpret this one.                                                                          | maxLength: 20                                                               |
| `createdAt`              | `string`   | ✅       | Client-declared timestamp when this record was originally created                                                                                                                                                                                                                                                                                                                                 |                                                                             |
| `signatures`             | `ref`      | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                                                                                                                             |                                                                             |

#### Defs

##### `org.hypercerts.collection#item`

An item in a collection, with an identifier and optional weight.

| Property         | Type     | Required | Description                                                                                                                                                                                              | Comments       |
| ---------------- | -------- | -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------- |
| `itemIdentifier` | `ref`    | ✅       | Strong reference to an item in this collection. Items can be activities (org.hypercerts.claim.activity), features (org.hypercerts.entity.feature), and/or other collections (org.hypercerts.collection). |                |
| `itemWeight`     | `string` | ❌       | Optional weight for this item (positive numeric value stored as string). Weights do not need to sum to a specific total; normalization can be performed by the consuming application as needed.          | maxLength: 100 |

---

### `org.hypercerts.context.acknowledgement`

**Description:** Acknowledges a record (subject) or its relationship in a context. Created in the acknowledging actor's repo to form a bidirectional link. Examples: a contributor acknowledging inclusion in an activity, an activity owner acknowledging inclusion in a collection, or a record owner acknowledging an evaluation.

**Key:** `tid`

#### Properties

| Property       | Type      | Required | Description                                                                                                                                                                                                          | Comments                             |
| -------------- | --------- | -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------ |
| `subject`      | `ref`     | ✅       | The record being acknowledged (e.g. an activity, a contributor information record, an evaluation).                                                                                                                   |                                      |
| `context`      | `union`   | ❌       | Context for the acknowledgement (e.g. the collection that includes an activity, or the activity that includes a contributor). A URI for a lightweight reference or a strong reference for content-hash verification. |                                      |
| `acknowledged` | `boolean` | ✅       | Whether the relationship is acknowledged (true) or rejected (false).                                                                                                                                                 |                                      |
| `comment`      | `string`  | ❌       | Optional plain-text comment providing additional context or reasoning.                                                                                                                                               | maxLength: 10000, maxGraphemes: 1000 |
| `createdAt`    | `string`  | ✅       | Client-declared timestamp when this record was originally created.                                                                                                                                                   |                                      |
| `signatures`   | `ref`     | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                |                                      |

---

### `org.hypercerts.context.attachment`

**Description:** An attachment providing commentary, context, evidence, or documentary material related to a hypercert record (e.g. an activity, project, claim, or evaluation) or related to an account profile.

**Key:** `tid`

#### Properties

| Property                 | Type       | Required | Description                                                                                                                                                                                                                                                                                                                                                                                                          | Comments                                                                                           |
| ------------------------ | ---------- | -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| `subjects`               | `ref[]`    | ❌       | References to the subject(s) the attachment is about: an activity claim, a collection, a measurement, an evaluation, another attachment (for a comment on it), or an account profile (app.certified.actor.profile). A standalone update by its author points at the author's own profile: it is an update about the author. Optional: omit it only when the attachment is recorded before the claim it will support. | maxLength: 100                                                                                     |
| `contentType`            | `string`   | ❌       | The type of attachment. Values beyond the known set are permitted.                                                                                                                                                                                                                                                                                                                                                   | maxLength: 64, Known values: `update`, `report`, `audit`, `evidence`, `testimonial`, `methodology` |
| `content`                | `union[]`  | ❌       | The files, documents, or external references included in this attachment record.                                                                                                                                                                                                                                                                                                                                     | maxLength: 100                                                                                     |
| `title`                  | `string`   | ✅       | Display title for this attachment (e.g. 'Impact Assessment Report', 'Audit Findings')                                                                                                                                                                                                                                                                                                                                | maxLength: 256                                                                                     |
| `shortDescription`       | `string`   | ❌       | Short summary of this attachment, suitable for previews and list views. Rich text annotations may be provided via `shortDescriptionFacets`.                                                                                                                                                                                                                                                                          | maxLength: 3000, maxGraphemes: 300                                                                 |
| `shortDescriptionFacets` | `ref[]`    | ❌       | Rich text annotations for `shortDescription` (mentions, URLs, hashtags, etc).                                                                                                                                                                                                                                                                                                                                        |                                                                                                    |
| `description`            | `union`    | ❌       | Long-form description of the attachment. An inline string for plain text or markdown, a Leaflet linear document for rich-text content, or a strong reference to an external description record.                                                                                                                                                                                                                      |                                                                                                    |
| `langs`                  | `string[]` | ❌       | Human language(s) of this record's text fields, as BCP-47 language tags (e.g. 'es', 'pt-BR'); up to three for mixed-language text. Set by the writing app from the text the author wrote, with the author able to correct it; never from the interface language or a profile preference alone. A hint for readers, not a guarantee: consumers must not hide a record because it lacks this field.                    | maxLength: 3                                                                                       |
| `location`               | `ref`      | ❌       | A strong reference to the location where this attachment's subject matter occurred. The record referenced must conform with the lexicon app.certified.location.                                                                                                                                                                                                                                                      |                                                                                                    |
| `tags`                   | `ref[]`    | ❌       | References to org.hypercerts.vocab.tag records classifying this record. All listed tags apply simultaneously (logical AND); the array carries no ordering, weighting, negation, inheritance, or rule logic, and never will — any future expression logic must arrive as a new field and must never reinterpret this one.                                                                                             | maxLength: 20                                                                                      |
| `capturedAt`             | `string`   | ❌       | Client-declared time when the attached material was captured (e.g. when a photo was taken), as distinct from createdAt. Omit if capture time is unknown, if only a local time without timezone offset or only a date is known, or if no single capture time applies. Not a coverage interval.                                                                                                                        |                                                                                                    |
| `createdAt`              | `string`   | ✅       | Client-declared timestamp when this record was originally created.                                                                                                                                                                                                                                                                                                                                                   |                                                                                                    |
| `signatures`             | `ref`      | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                                                                                                                                                |                                                                                                    |

---

### `org.hypercerts.context.evaluation`

**Description:** An evaluation of a hypercert record (e.g. an activity and its impact).

**Key:** `tid`

#### Properties

| Property       | Type      | Required | Description                                                                                                                                                            | Comments                            |
| -------------- | --------- | -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------- |
| `subject`      | `ref`     | ❌       | A strong reference to what is being evaluated (e.g. activity, measurement, contribution, etc.)                                                                         |                                     |
| `evaluators`   | `ref[]`   | ✅       | DIDs of the evaluators                                                                                                                                                 | maxLength: 1000                     |
| `content`      | `union[]` | ❌       | Evaluation data (URIs or blobs) containing detailed reports or methodology                                                                                             | maxLength: 100                      |
| `measurements` | `ref[]`   | ❌       | Optional references to the measurements that contributed to this evaluation. The record(s) referenced must conform with the lexicon org.hypercerts.context.measurement | maxLength: 100                      |
| `summary`      | `string`  | ✅       | Brief evaluation summary                                                                                                                                               | maxLength: 5000, maxGraphemes: 1000 |
| `score`        | `ref`     | ❌       | Overall score for an evaluation on a numeric scale.                                                                                                                    |                                     |
| `location`     | `ref`     | ❌       | An optional reference for georeferenced evaluations. The record referenced must conform with the lexicon app.certified.location.                                       |                                     |
| `createdAt`    | `string`  | ✅       | Client-declared timestamp when this record was originally created                                                                                                      |                                     |
| `signatures`   | `ref`     | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                  |                                     |

#### Defs

##### `org.hypercerts.context.evaluation#score`

Overall score for an evaluation on a numeric scale.

| Property | Type     | Required | Description                                                                   | Comments      |
| -------- | -------- | -------- | ----------------------------------------------------------------------------- | ------------- |
| `min`    | `string` | ✅       | Minimum value of the scale as a numeric string (e.g. '0', '1').               | maxLength: 50 |
| `max`    | `string` | ✅       | Maximum value of the scale as a numeric string (e.g. '5', '10').              | maxLength: 50 |
| `value`  | `string` | ✅       | Score within the inclusive range [min, max] as a numeric string (e.g. '3.7'). | maxLength: 50 |

---

### `org.hypercerts.context.measurement`

**Description:** Measurement data related to one or more records (e.g. activities, projects, etc.).

**Key:** `tid`

#### Properties

| Property        | Type       | Required | Description                                                                                                                                             | Comments                           |
| --------------- | ---------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------- |
| `subjects`      | `ref[]`    | ❌       | Strong references to the records this measurement refers to (e.g. activities, projects, or claims).                                                     | maxLength: 100                     |
| `metric`        | `string`   | ✅       | The metric being measured, e.g. forest area restored, number of users, etc.                                                                             | maxLength: 500                     |
| `unit`          | `string`   | ✅       | The unit of the measured value (e.g. kg CO₂e, hectares, %, index score).                                                                                | maxLength: 50                      |
| `value`         | `string`   | ✅       | The measured value as a numeric string (e.g. '1234.56')                                                                                                 | maxLength: 500                     |
| `startDate`     | `string`   | ❌       | The start date and time when the measurement began.                                                                                                     |                                    |
| `endDate`       | `string`   | ❌       | The end date and time when the measurement ended. For one-time measurements, this should equal the start date.                                          |                                    |
| `locations`     | `ref[]`    | ❌       | Optional geographic references related to where the measurement was taken. Each referenced record must conform with the app.certified.location lexicon. | maxLength: 100                     |
| `methodType`    | `string`   | ❌       | Short identifier for the measurement methodology                                                                                                        | maxLength: 30                      |
| `methodURI`     | `string`   | ❌       | URI to methodology documentation, standard protocol, or measurement procedure                                                                           |                                    |
| `evidenceURI`   | `string[]` | ❌       | URIs to related evidence or underlying data (e.g. org.hypercerts.claim.evidence records or raw datasets)                                                | maxLength: 50                      |
| `measurers`     | `ref[]`    | ❌       | DIDs of the entities that performed this measurement                                                                                                    | maxLength: 100                     |
| `comment`       | `string`   | ❌       | Short comment of this measurement, suitable for previews and list views. Rich text annotations may be provided via `commentFacets`.                     | maxLength: 3000, maxGraphemes: 300 |
| `commentFacets` | `ref[]`    | ❌       | Rich text annotations for `comment` (mentions, URLs, hashtags, etc).                                                                                    |                                    |
| `createdAt`     | `string`   | ✅       | Client-declared timestamp when this record was originally created                                                                                       |                                    |
| `signatures`    | `ref`      | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                   |                                    |

---

### `org.hypercerts.entity.feature`

**Description:** A record for a non-agent subject that other records (measurements, evaluations, etc.) can be about, for example a land zone or an ecological stratum. It carries the subject's identity, classification, and optional published spatial representations. Geometry lives in app.certified.location records; grouping lives in org.hypercerts.collection records.

**Key:** `any`

#### Properties

| Property      | Type       | Required | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | Comments                                       |
| ------------- | ---------- | -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| `type`        | `string`   | ❌       | The coarse kind of subject this feature is. The initial known kinds are spatial — zone (an area a steward authors and manages) and stratum (an analytical unit derived from a model or methodology) — but the record is subject-general: spatiality comes from the presence of locations, not from type, and further kinds may be documented as adoption demonstrates need. This is not the feature's role or detailed classification — those are expressed through tags. Values beyond the known set are permitted.                                                                                                                                                                                             | maxLength: 64, Known values: `zone`, `stratum` |
| `title`       | `string`   | ✅       | Display name of the feature.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | maxLength: 800, maxGraphemes: 80               |
| `description` | `union`    | ❌       | Long-form description of the feature, as an inline string, a Leaflet document, or a reference to another record.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                                                |
| `langs`       | `string[]` | ❌       | Human language(s) of this record's text fields, as BCP-47 language tags (e.g. 'es', 'pt-BR'); up to three for mixed-language text. Set by the writing app from the text the author wrote, with the author able to correct it; never from the interface language or a profile preference alone. A hint for readers, not a guarantee: consumers must not hide a record because it lacks this field.                                                                                                                                                                                                                                                                                                                | maxLength: 3                                   |
| `locations`   | `ref[]`    | ❌       | Optional published spatial representations of this feature. Each referenced record must conform with app.certified.location. Multiple entries are alternative representations of the same subject at different precisions or encodings — never different places. Genuinely different places are either one MultiPolygon inside a single location record, or separate features. Writers SHOULD list entries in publisher-preferred order, most preferred first. All referenced locations are public once published: for sensitive subjects, publish only a coarse representation and keep exact geometry unpublished. An empty or absent array is valid: the subject's geometry is unpublished or not applicable. | maxLength: 1000                                |
| `tags`        | `ref[]`    | ❌       | References to org.hypercerts.vocab.tag records classifying this record. All listed tags apply simultaneously (logical AND); the array carries no ordering, weighting, negation, inheritance, or rule logic, and never will — any future expression logic must arrive as a new field and must never reinterpret this one.                                                                                                                                                                                                                                                                                                                                                                                         | maxLength: 20                                  |
| `sameAs`      | `string[]` | ❌       | URIs of external identifiers that denote the same real-world subject, for example a cadastral parcel ID or a gazetteer entry. Entity identity only; vocabulary concordance belongs on org.hypercerts.vocab.tag.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | maxLength: 20                                  |
| `createdAt`   | `string`   | ✅       | Client-declared timestamp when this record was originally created.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |                                                |
| `signatures`  | `ref`      | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |                                                |

---

### `org.hypercerts.funding.receipt`

**Description:** Records a payment from a sender to a recipient. Any party may record it, and the sender may stay anonymous. When the sender chose the recipient, record one receipt to the final recipient even if platforms or hosts passed the funds on. When an intermediary chose (regranting), record the payment into it and each onward payment as separate receipts. A receipt may be updated in place under the same record key: its URI does not change, so references by URI keep resolving, but a strongRef (as likes and reposts use) still pins the earlier CID, and signatures bind to content and must be renewed. An earlier version cannot be recalled from readers that kept it.

**Key:** `tid`

#### Properties

| Property         | Type     | Required | Description                                                                                                                                                                                                                                                                                                                                                                       | Comments                                                                                                                              |
| ---------------- | -------- | -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| `from`           | `union`  | ❌       | The sender of the funds (a free-text string, an account DID, or a strong reference to a record). Optional — omit to represent anonymity. Name a sender only if they chose to be named: from can be added later by updating the receipt in place, but removing it later only hides the name from the current version, and an onchain transactionId still names the sending wallet. |                                                                                                                                       |
| `to`             | `union`  | ✅       | The recipient of the funds (a free-text string, an account DID, or a strong reference to a record).                                                                                                                                                                                                                                                                               |                                                                                                                                       |
| `via`            | `union`  | ❌       | Optional intermediary that facilitated or processed the payment (funding platform, payment servicer, broker).                                                                                                                                                                                                                                                                     |                                                                                                                                       |
| `type`           | `string` | ❌       | What the payment is: a donation (a gift from the sender), a match (funds a matching pool allocated on the strength of other gifts) or a grant (funds awarded through a selection process). Values beyond the known set are permitted. Omit if unknown.                                                                                                                            | maxLength: 50, Known values: `donation`, `match`, `grant`                                                                             |
| `amount`         | `string` | ❌       | Gross amount the sender paid, before fees, as a numeric string (e.g. '1000.50'). Omit if unknown, and set netAmount instead.                                                                                                                                                                                                                                                      | maxLength: 50                                                                                                                         |
| `currency`       | `string` | ❌       | Currency of amount: an ISO 4217 code for fiat (e.g. EUR), a token ticker for digital assets (e.g. USDC). This is what marks the funds as fiat or digital. Set it whenever amount is set.                                                                                                                                                                                          | maxLength: 10                                                                                                                         |
| `netAmount`      | `string` | ❌       | What the recipient received after fees and conversion, as a numeric string in netCurrency.                                                                                                                                                                                                                                                                                        | maxLength: 50                                                                                                                         |
| `netCurrency`    | `string` | ❌       | Currency of netAmount: an ISO 4217 code for fiat, a token ticker for digital assets. Set it whenever netAmount is set.                                                                                                                                                                                                                                                            | maxLength: 10                                                                                                                         |
| `paymentRail`    | `string` | ❌       | How the sender paid. Use 'payment_processor' only when the underlying method is unknown.                                                                                                                                                                                                                                                                                          | maxLength: 50, Known values: `onchain`, `bank_transfer`, `card`, `direct_debit`, `mobile_money`, `payment_processor`, `cash`, `check` |
| `paymentNetwork` | `string` | ❌       | Where transactionId can be looked up: the chain for onchain payments, preferably as a CAIP-2 ID (e.g. 'eip155:1'), otherwise the processor or scheme (e.g. stripe, sepa). Set it whenever transactionId is a transaction hash.                                                                                                                                                    | maxLength: 50                                                                                                                         |
| `transactionId`  | `string` | ❌       | ID of the sender's payment, not of a platform's later payout: a transaction hash for onchain payments, otherwise the processor's or scheme's reference. Receipts are public: prefer opaque processor IDs to bank references, and note that a hash reveals the sender's wallet even when from is omitted.                                                                          | maxLength: 256                                                                                                                        |
| `for`            | `ref`    | ❌       | Optional strong reference to the activity, project, or organization this funding relates to.                                                                                                                                                                                                                                                                                      |                                                                                                                                       |
| `notes`          | `string` | ❌       | Optional notes or additional context for this funding receipt.                                                                                                                                                                                                                                                                                                                    | maxLength: 500                                                                                                                        |
| `occurredAt`     | `string` | ❌       | Timestamp when the payment occurred.                                                                                                                                                                                                                                                                                                                                              |                                                                                                                                       |
| `createdAt`      | `string` | ✅       | Client-declared timestamp when this receipt record was created.                                                                                                                                                                                                                                                                                                                   |                                                                                                                                       |
| `signatures`     | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                                                                                                             |                                                                                                                                       |

#### Defs

##### `org.hypercerts.funding.receipt#text`

A free-text string value (e.g. a display name, wallet address, or other identifier).

| Property | Type     | Required | Description       | Comments        |
| -------- | -------- | -------- | ----------------- | --------------- |
| `value`  | `string` | ✅       | The string value. | maxLength: 2048 |

---

### `org.hypercerts.vocab.tag`

**Description:** A reusable vocabulary term for classifying any Hypercerts record — for example a land-cover class, a zone role, or a methodology. The vocabulary is domain-general; geospatial categories are simply its first entries. The schema carries portable term data; named vocabulary profiles decide which published terms and attachment points they recognize. Recommended record key: the deterministic form <category>.<key> (for example zone-role.site), as defined by the governing vocabulary profile; Lexicon validation cannot bind a record key to body fields, so writers and indexers enforce that agreement. A tag reference pins the specific version (CID) of the term that the referencing record classified against; consumers resolve the term's current status and supersession by its URI.

**Key:** `any`

#### Properties

| Property            | Type       | Required | Description                                                                                                                                                                                                                                                                                                            | Comments                                                                                                                                             |
| ------------------- | ---------- | -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| `key`               | `string`   | ✅       | Stable lowercase machine identifier for this term within its publisher and category, for example boundary or mangrove. Must not contain dots, so that the recommended <category>.<key> record key remains unambiguous.                                                                                                 | maxLength: 120                                                                                                                                       |
| `name`              | `string`   | ✅       | Human-readable display name of the term.                                                                                                                                                                                                                                                                               | maxLength: 200                                                                                                                                       |
| `category`          | `string`   | ✅       | The classification axis this term belongs to, for example land-cover or zone-role. One term belongs to one category; a subject may carry tags from many categories at once. Values beyond the known set are permitted. Must not contain dots, so that the recommended <category>.<key> record key remains unambiguous. | maxLength: 50, Known values: `zone-role`, `land-cover`, `ecosystem-type`, `stratum-class`, `tenure`, `methodology`, `outcome-class`, `evidence-type` |
| `description`       | `string`   | ❌       | Definition and scope notes for the term, written so a reader outside the publishing organization can apply it consistently.                                                                                                                                                                                            | maxLength: 10000, maxGraphemes: 1000                                                                                                                 |
| `broader`           | `ref[]`    | ❌       | Optional references to directly broader terms, forming a polyhierarchy (a term may have several broader terms). Each referenced record must conform with org.hypercerts.vocab.tag.                                                                                                                                     | maxLength: 20                                                                                                                                        |
| `status`            | `string`   | ✅       | Lifecycle status of the term: proposed (submitted, not yet governed), accepted (in active governed use), or deprecated (retired; see supersededBy). Values beyond the known set are permitted.                                                                                                                         | maxLength: 20, Known values: `proposed`, `accepted`, `deprecated`                                                                                    |
| `supersededBy`      | `ref`      | ❌       | The replacement term for a deprecated term, letting consumers roll classifications forward without rewriting published records. The referenced record must conform with org.hypercerts.vocab.tag.                                                                                                                      |                                                                                                                                                      |
| `aliases`           | `string[]` | ❌       | Alternative human-readable labels and abbreviations for search and display. Aliases carry no identity: references always point at the record, not at a label.                                                                                                                                                          | maxLength: 50                                                                                                                                        |
| `sameAs`            | `string[]` | ❌       | URIs of exactly equivalent concepts in external vocabularies, for example ENVO, IUCN GET, OSM tag conventions, or registry methodology identifiers. Exact matches only; typed broader/narrower/close mappings are a named future field.                                                                                | maxLength: 20                                                                                                                                        |
| `referenceDocument` | `union`    | ❌       | A document defining or motivating this term, as a URI or an attached small blob.                                                                                                                                                                                                                                       |                                                                                                                                                      |
| `createdAt`         | `string`   | ✅       | Client-declared timestamp when this record was originally created.                                                                                                                                                                                                                                                     |                                                                                                                                                      |
| `signatures`        | `ref`      | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                                                  |                                                                                                                                                      |

---

### `org.hypercerts.workscope.cel`

**Description:** A structured, machine-evaluable work scope definition using CEL (Common Expression Language). Tags referenced in the expression correspond to org.hypercerts.workscope.tag keys. See https://github.com/google/cel-spec. Note: this is intentionally type 'object' (not 'record') so it can be directly embedded inline in union types (e.g., activity.workScope) without requiring a separate collection or strongRef indirection.

#### Properties

| Property     | Type     | Required | Description                                                                                                                                                                         | Comments                             |
| ------------ | -------- | -------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------ |
| `expression` | `string` | ✅       | A CEL expression encoding the work scope conditions. Example: scope.hasAll(['mangrove_restoration', 'environmental_education']) && location.country == 'KE'                         | maxLength: 10000, maxGraphemes: 5000 |
| `usedTags`   | `ref[]`  | ✅       | Strong references to org.hypercerts.workscope.tag records used in the expression. Enables fast indexing by AT-URI and provides referential integrity to the underlying tag records. | maxLength: 100                       |
| `version`    | `string` | ✅       | CEL context schema version.                                                                                                                                                         | maxLength: 16, Known values: `v1`    |
| `createdAt`  | `string` | ✅       | Client-declared timestamp when this expression was originally created.                                                                                                              |                                      |

---

### `org.hypercerts.workscope.tag`

**Description:** A reusable scope atom for work scope logic expressions. Scopes can represent topics, languages, domains, deliverables, methods, regions, tags, or other categorical labels. Tags are composed into structured expressions via CEL (Common Expression Language) on activity records.

**Key:** `tid`

#### Properties

| Property            | Type       | Required | Description                                                                                                                                                                            | Comments                                                             |
| ------------------- | ---------- | -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------- |
| `key`               | `string`   | ✅       | Lowercase, underscore-separated machine-readable key for this scope (e.g., 'mangrove_restoration', 'biodiversity_monitoring'). Used as the canonical identifier in CEL expressions.    | maxLength: 120                                                       |
| `name`              | `string`   | ✅       | Human-readable name for this scope.                                                                                                                                                    | maxLength: 200                                                       |
| `category`          | `string`   | ❌       | Category type of this scope. Values beyond the known set are permitted.                                                                                                                | maxLength: 50, Known values: `topic`, `language`, `domain`, `method` |
| `description`       | `string`   | ❌       | Optional longer description of this scope.                                                                                                                                             | maxLength: 10000, maxGraphemes: 1000                                 |
| `parent`            | `ref`      | ❌       | Optional strong reference to a parent work scope tag record for taxonomy/hierarchy support. The record referenced must conform with the lexicon org.hypercerts.workscope.tag.          |                                                                      |
| `status`            | `string`   | ❌       | Lifecycle status of this tag. Communities propose tags, curators accept them, deprecated tags point to replacements via supersededBy. Values beyond the known set are permitted.       | maxLength: 20, Known values: `proposed`, `accepted`, `deprecated`    |
| `supersededBy`      | `ref`      | ❌       | When status is 'deprecated', points to the replacement work scope tag record. The record referenced must conform with the lexicon org.hypercerts.workscope.tag.                        |                                                                      |
| `aliases`           | `string[]` | ❌       | Alternative human-readable names for this scope (e.g., translations, abbreviations, or common synonyms). Unlike sameAs, these are plain-text labels, not links to external ontologies. | maxLength: 50                                                        |
| `sameAs`            | `string[]` | ❌       | URIs to semantically equivalent concepts in external ontologies or taxonomies (e.g., Wikidata QIDs, ENVO terms, SDG targets). Used for interoperability, not as documentation.         | maxLength: 20                                                        |
| `referenceDocument` | `union`    | ❌       | Link to a governance or reference document where this work scope tag is defined and further explained.                                                                                 |                                                                      |
| `createdAt`         | `string`   | ✅       | Client-declared timestamp when this record was originally created.                                                                                                                     |                                                                      |
| `signatures`        | `ref`      | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                  |                                                                      |

---

## Certified Lexicons

Certified lexicons are common/shared lexicons that can be used across multiple protocols.

### `app.certified.location`

**Description:** A location reference

**Key:** `tid`

#### Properties

| Property       | Type     | Required | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | Comments                                                                                                                                              |
| -------------- | -------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| `lpVersion`    | `string` | ✅       | The version of the Location Protocol                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | maxLength: 10                                                                                                                                         |
| `srs`          | `string` | ✅       | The Spatial Reference System URI (e.g., http://www.opengis.net/def/crs/OGC/1.3/CRS84) that defines the coordinate system.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | maxLength: 100                                                                                                                                        |
| `locationType` | `string` | ✅       | An identifier for the format of the location data. Use `country-code` for uppercase ISO 3166-1 alpha-2 codes in `location.string` (e.g. `CH`). Although this lexicon requires `srs`, it has no meaning for this type and consumers must ignore it. Use `geojson-point` for a single GeoJSON Point; use `geojson` as the catch-all for any other GeoJSON geometry (Polygon, MultiPolygon, FeatureCollection, etc.) — the inner payload's own GeoJSON `type` field carries the specifics. Values beyond the known set are permitted; see the Location Protocol spec for the canonical registry: https://spec.decentralizedgeo.org/specification/location-types/#location-type-registry | maxLength: 20, Known values: `coordinate-decimal`, `geojson-point`, `geojson`, `h3`, `geohash`, `wkt`, `address`, `country-code`, `scaledCoordinates` |
| `location`     | `union`  | ✅       | The location of where the work was performed as a URI, blob, or inline string.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |                                                                                                                                                       |
| `name`         | `string` | ❌       | Human-readable name for this location (e.g. 'Golden Gate Park', 'San Francisco Bay Area')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | maxLength: 1000, maxGraphemes: 100                                                                                                                    |
| `description`  | `string` | ❌       | Additional context about this location, such as its significance to the work or specific boundaries                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | maxLength: 2000, maxGraphemes: 500                                                                                                                    |
| `createdAt`    | `string` | ✅       | Client-declared timestamp when this record was originally created                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |                                                                                                                                                       |
| `signatures`   | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |                                                                                                                                                       |

#### Defs

##### `app.certified.location#string`

A location represented as a string, e.g. coordinates or a small GeoJSON string.

| Property | Type     | Required | Description               | Comments                             |
| -------- | -------- | -------- | ------------------------- | ------------------------------------ |
| `string` | `string` | ✅       | The location string value | maxLength: 10000, maxGraphemes: 1000 |

---

### `app.certified.badge.definition`

**Description:** Defines a badge that can be awarded via badge award records to users, projects, or activity claims.

**Key:** `tid`

#### Properties

| Property         | Type     | Required | Description                                                                              | Comments                                                                                                                    |
| ---------------- | -------- | -------- | ---------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| `badgeType`      | `string` | ✅       | Category of the badge. Values beyond the known set are permitted.                        | maxLength: 100, Known values: `endorsement`, `verification`, `participation`, `certification`, `affiliation`, `recognition` |
| `title`          | `string` | ✅       | Human-readable title of the badge.                                                       | maxLength: 256                                                                                                              |
| `icon`           | `blob`   | ❌       | Icon representing the badge, stored as a blob for compact visual display.                | maxSize: 1048576, accepts: `image/png`, `image/jpeg`, `image/webp`, `image/svg+xml`                                         |
| `description`    | `string` | ❌       | Optional short statement describing what the badge represents.                           | maxLength: 5000, maxGraphemes: 500                                                                                          |
| `allowedIssuers` | `ref[]`  | ❌       | Optional allowlist of DIDs allowed to issue this badge. If omitted, anyone may issue it. | maxLength: 100                                                                                                              |
| `createdAt`      | `string` | ✅       | Client-declared timestamp when this record was originally created                        |                                                                                                                             |
| `signatures`     | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                    |                                                                                                                             |

---

### `app.certified.badge.award`

**Description:** Records a badge award to a user, project, or activity claim.

**Key:** `tid`

#### Properties

| Property     | Type     | Required | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           | Comments        |
| ------------ | -------- | -------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------- |
| `badge`      | `ref`    | ✅       | Strong reference to the badge definition at the time of award. The record referenced must conform with the lexicon app.certified.badge.definition.                                                                                                                                                                                                                                                                                                                                                    |                 |
| `subject`    | `union`  | ✅       | Entity the badge award is for (either an account DID or any specific AT Protocol record), e.g. a user, a project, or a specific activity claim.                                                                                                                                                                                                                                                                                                                                                       |                 |
| `note`       | `string` | ❌       | Optional statement explaining the reason for this badge award.                                                                                                                                                                                                                                                                                                                                                                                                                                        | maxLength: 500  |
| `url`        | `string` | ❌       | Optional URL the badge award links to.                                                                                                                                                                                                                                                                                                                                                                                                                                                                | maxLength: 2048 |
| `validFrom`  | `string` | ❌       | When the badge starts to apply, which can differ from when this record was written (e.g. a certification granted in 2019 and recorded later). If omitted, the badge applies from createdAt. For date-only values, use midnight UTC (e.g. '2019-06-01T00:00:00.000Z'); consumers should treat only the date portion as canonical.                                                                                                                                                                      |                 |
| `validUntil` | `string` | ❌       | When the badge stops applying, e.g. when a certification lapses or a verification needs renewal. Must not be earlier than validFrom. If omitted, the badge has no end date. After this time the award is expired: still a true historical statement ('was certified until …'), and clients should present it as such. Expiry is not revocation; to revoke an award, the issuer deletes the record. For date-only values, use midnight UTC; consumers should treat only the date portion as canonical. |                 |
| `createdAt`  | `string` | ✅       | Client-declared timestamp when this record was originally created                                                                                                                                                                                                                                                                                                                                                                                                                                     |                 |
| `signatures` | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                                                                                                                                                                                                                                 |                 |

---

### `app.certified.badge.response`

**Description:** Recipient response to a badge award.

**Key:** `tid`

#### Properties

| Property     | Type     | Required | Description                                                                                                                            | Comments                             |
| ------------ | -------- | -------- | -------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------ |
| `badgeAward` | `ref`    | ✅       | Strong reference to the badge award being responded to. The record referenced must conform with the lexicon app.certified.badge.award. |                                      |
| `response`   | `string` | ✅       | The recipient’s response for the badge (accepted or rejected).                                                                         | Known values: `accepted`, `rejected` |
| `weight`     | `string` | ❌       | Optional relative weight for accepted badges, assigned by the recipient.                                                               | maxLength: 50                        |
| `createdAt`  | `string` | ✅       | Client-declared timestamp when this record was originally created                                                                      |                                      |
| `signatures` | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                  |                                      |

---

### `app.certified.actor.organization`

**Description:** Extended metadata for an organization actor. Complements the base actor profile (app.certified.actor.profile), which holds the display name, description, website, avatar, and banner, with organization-specific fields such as legal name, full logo, public contact email, legal structure, reference links, and locations.

**Key:** `literal:self`

#### Properties

| Property              | Type       | Required | Description                                                                                                                                                                                                                                                                                                                                                                                                         | Comments                           |
| --------------------- | ---------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------- |
| `legalName`           | `string`   | ❌       | The organization's registered legal name. The public-facing name belongs in app.certified.actor.profile displayName.                                                                                                                                                                                                                                                                                                | maxLength: 2560, maxGraphemes: 256 |
| `logo`                | `union`    | ❌       | The organization's full logo: a wordmark, or a combination mark pairing the symbol with the name. Used where the logo appears without the name beside it, such as partner listings or badge displays. Prefer a horizontal image with a transparent background (PNG or WebP). The square symbol alone (brandmark) belongs in app.certified.actor.profile avatar, which is cropped to a square or circle.             |                                    |
| `publicEmail`         | `string`   | ❌       | A contact email address the organization wants shown publicly (e.g. 'hello@example.org'). Records are public, so never put a personal or internal address here.                                                                                                                                                                                                                                                     | maxLength: 254                     |
| `organizationType`    | `string[]` | ❌       | Legal or operational structures of the organization (e.g. 'nonprofit', 'ngo', 'government', 'social-enterprise', 'cooperative').                                                                                                                                                                                                                                                                                    | maxLength: 10                      |
| `urls`                | `ref[]`    | ❌       | Additional reference URLs, each with a display label: social media profiles, contact pages, donation links, and similar. The organization's main website belongs in app.certified.actor.profile website, not here.                                                                                                                                                                                                  |                                    |
| `location`            | `ref`      | ❌       | A strong reference to the organization's primary location: where it is based, and where it is shown when a map displays one point per organization. The referenced record must conform with the lexicon app.certified.location. Because a strong reference pins a specific version (CID) of that record, update this reference whenever the location record is edited. Further locations go in additionalLocations. |                                    |
| `additionalLocations` | `ref[]`    | ❌       | Strong references to further locations where the organization operates, such as branches, outlets, or field offices. Excludes the primary location, which is in location; do not repeat it here. Each referenced record must conform with the lexicon app.certified.location. As with location, update a reference whenever its record is edited.                                                                   | maxLength: 1000                    |
| `foundedDate`         | `string`   | ❌       | When the organization was established. Stored as datetime per ATProto conventions (no date-only format exists). Clients should use midnight UTC (e.g., '2005-01-01T00:00:00.000Z'); consumers should treat only the date portion as canonical.                                                                                                                                                                      |                                    |
| `longDescription`     | `union`    | ❌       | Long-form description of the organization, such as its mission, history, or detailed project narrative. An inline string for plain text or markdown, a Leaflet linear document record embedded directly, or a strong reference to an existing document record.                                                                                                                                                      |                                    |
| `langs`               | `string[]` | ❌       | Human language(s) of this record's text fields, as BCP-47 language tags (e.g. 'es', 'pt-BR'); up to three for mixed-language text. Set by the writing app from the text the author wrote, with the author able to correct it; never from the interface language or a profile preference alone. A hint for readers, not a guarantee: consumers must not hide a record because it lacks this field.                   | maxLength: 3                       |
| `visibility`          | `string`   | ❌       | Controls whether the organization or project is publicly discoverable on platforms that honor this setting.                                                                                                                                                                                                                                                                                                         | Known values: `public`, `unlisted` |
| `createdAt`           | `string`   | ✅       | Client-declared timestamp when this record was originally created.                                                                                                                                                                                                                                                                                                                                                  |                                    |
| `signatures`          | `ref`      | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                                                                                                                                               |                                    |

#### Defs

##### `app.certified.actor.organization#urlItem`

A labeled URL reference.

| Property | Type     | Required | Description                                                        | Comments                             |
| -------- | -------- | -------- | ------------------------------------------------------------------ | ------------------------------------ |
| `url`    | `string` | ✅       | The URL.                                                           | maxLength: 10000, maxGraphemes: 2048 |
| `label`  | `string` | ❌       | Optional human-readable label for this URL (e.g. 'Donation page'). | maxLength: 640, maxGraphemes: 64     |

---

### `app.certified.actor.profile`

**Description:** A declaration of a Certified account profile.

**Key:** `literal:self`

#### Properties

| Property      | Type       | Required | Description                                                                                                                                                                                                                                                                                                                                                                                       | Comments                           |
| ------------- | ---------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------- |
| `displayName` | `string`   | ❌       | Display name for the account. For an organization, the public-facing name it uses in communications; a different registered legal name belongs in app.certified.actor.organization legalName.                                                                                                                                                                                                     | maxLength: 640, maxGraphemes: 64   |
| `description` | `string`   | ❌       | Free-form profile description text.                                                                                                                                                                                                                                                                                                                                                               | maxLength: 2560, maxGraphemes: 256 |
| `pronouns`    | `string`   | ❌       | Free-form pronouns text.                                                                                                                                                                                                                                                                                                                                                                          | maxLength: 200, maxGraphemes: 20   |
| `langs`       | `string[]` | ❌       | Human language(s) of this record's text fields, as BCP-47 language tags (e.g. 'es', 'pt-BR'); up to three for mixed-language text. Set by the writing app from the text the author wrote, with the author able to correct it; never from the interface language or a profile preference alone. A hint for readers, not a guarantee: consumers must not hide a record because it lacks this field. | maxLength: 3                       |
| `website`     | `string`   | ❌       | Account website URL                                                                                                                                                                                                                                                                                                                                                                               |                                    |
| `avatar`      | `union`    | ❌       | Small image to be displayed next to posts from account. AKA, 'profile picture'. Clients crop it to a square or circle, so an organization should use its brandmark (the symbol without the name); the full logo belongs in app.certified.actor.organization logo.                                                                                                                                 |                                    |
| `banner`      | `union`    | ❌       | Larger horizontal image to display behind profile view.                                                                                                                                                                                                                                                                                                                                           |                                    |
| `createdAt`   | `string`   | ✅       | Client-declared timestamp when this record was originally created                                                                                                                                                                                                                                                                                                                                 |                                    |
| `signatures`  | `ref`      | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                                                                                                                             |                                    |

---

### `app.certified.authWrite`

**Title:** Manage your Certified data

**Detail:** Create, edit, and delete your Certified records (profile, badges, follows, likes, reposts, wallet links, and related data).

**Resource:** `repo`

**Collections:** `app.certified.actor.organization`, `app.certified.actor.profile`, `app.certified.badge.award`, `app.certified.badge.definition`, `app.certified.badge.response`, `app.certified.feed.like`, `app.certified.feed.repost`, `app.certified.graph.entityFollow`, `app.certified.graph.follow`, `app.certified.link.evm`, `app.certified.location`, `app.certified.signature.proof`

**Actions:** `create`, `update`, `delete`

---

### `app.certified.feed.like`

**Description:** Record declaring a 'like' of a piece of subject content. Social feedback only: a like carries no protocol meaning about the subject (it is not an evaluation, endorsement, or acknowledgement). Schema-compatible with app.bsky.feed.like.

**Key:** `tid`

#### Properties

| Property     | Type     | Required | Description                                                                                                                                                                                                                                                                                        |
| ------------ | -------- | -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `subject`    | `ref`    | ✅       | Strong reference to the record being liked. May be a record of any lexicon (e.g. an activity, a collection, or a repost's subject).                                                                                                                                                                |
| `createdAt`  | `string` | ✅       | Client-declared timestamp when this record was originally created.                                                                                                                                                                                                                                 |
| `via`        | `ref`    | ❌       | Optional strong reference to the record through which the subject was encountered, typically an app.certified.feed.repost. Lets AppViews credit the account that surfaced the subject. Mirrors the optional `via` field on app.bsky.feed.like; the referenced record may conform with any lexicon. |
| `signatures` | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                              |

---

### `app.certified.feed.repost`

**Description:** Record representing a 'repost' of an existing record, surfacing it to the reposter's followers. The subject is pinned by CID, so the repost refers to the version the reposter saw, not to later edits. Schema-compatible with app.bsky.feed.repost.

**Key:** `tid`

#### Properties

| Property     | Type     | Required | Description                                                                                                                                                                                                                                                                                                                       |
| ------------ | -------- | -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `subject`    | `ref`    | ✅       | Strong reference to the record being reposted. May be a record of any lexicon (e.g. an activity or a collection).                                                                                                                                                                                                                 |
| `createdAt`  | `string` | ✅       | Client-declared timestamp when this record was originally created.                                                                                                                                                                                                                                                                |
| `via`        | `ref`    | ❌       | Optional strong reference to the record through which the subject was encountered, typically another app.certified.feed.repost. Lets AppViews trace repost chains and credit the account that surfaced the subject. Mirrors the optional `via` field on app.bsky.feed.repost; the referenced record may conform with any lexicon. |
| `signatures` | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                                                                                                                             |

---

### `app.certified.graph.entityFollow`

**Description:** Record declaring a social 'follow' relationship with a non-account entity, such as a specific record. Account (DID) follows are out of scope and belong to app.certified.graph.follow. The subject is an open union so additional non-DID entity kinds can be added in the future.

**Key:** `tid`

#### Properties

| Property     | Type     | Required | Description                                                                                                                                                                                                                      |
| ------------ | -------- | -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `subject`    | `union`  | ✅       | The entity being followed. Must never include account DIDs; use app.certified.graph.follow for accounts.                                                                                                                         |
| `createdAt`  | `string` | ✅       | Client-declared timestamp when this record was originally created.                                                                                                                                                               |
| `via`        | `ref`    | ❌       | Optional strong reference to a record that mediated this follow (e.g. a starter pack or other curated list). Mirrors the optional `via` field on app.certified.graph.follow; the referenced record may conform with any lexicon. |
| `signatures` | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                            |

---

### `app.certified.graph.follow`

**Description:** Record declaring a social 'follow' relationship of another account.

**Key:** `tid`

#### Properties

| Property     | Type     | Required | Description                                                                                                                                                                                                                 |
| ------------ | -------- | -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `subject`    | `string` | ✅       | DID of the account being followed.                                                                                                                                                                                          |
| `createdAt`  | `string` | ✅       | Client-declared timestamp when this record was originally created.                                                                                                                                                          |
| `via`        | `ref`    | ❌       | Optional strong reference to a record that mediated this follow (e.g. a starter pack or other curated list). Mirrors the optional `via` field on app.bsky.graph.follow; the referenced record may conform with any lexicon. |
| `signatures` | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                                                                                                                                                       |

---

### `app.certified.link.evm`

**Description:** A verifiable link between an ATProto DID and an EVM wallet address, proven via a cryptographic signature. Currently supports EOA wallets via EIP-712 typed data signatures; the proof field is an open union to allow future signature methods.

**Key:** `any`

#### Properties

| Property     | Type     | Required | Description                                                                                                                                                                                                                             | Comments      |
| ------------ | -------- | -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------- |
| `address`    | `string` | ✅       | EVM wallet address (0x-prefixed, with EIP-55 checksum recommended).                                                                                                                                                                     | maxLength: 42 |
| `proof`      | `union`  | ✅       | Cryptographic proof of wallet ownership. The union is open to allow future proof methods (e.g. ERC-1271, ERC-6492). Each variant bundles its signature with the corresponding message format.                                           |               |
| `createdAt`  | `string` | ✅       | Client-declared timestamp when this record was originally created.                                                                                                                                                                      |               |
| `signatures` | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content. The EIP-712 `proof` field proves wallet consent (orthogonal trust statement); `signatures` proves record provenance (e.g. that a platform UI minted this record). |               |

#### Defs

##### `app.certified.link.evm#eip712Proof`

EOA wallet ownership proof via EIP-712 typed data signature. Contains both the structured message that was signed and the resulting signature.

| Property    | Type     | Required | Description                                                                                                                                     | Comments       |
| ----------- | -------- | -------- | ----------------------------------------------------------------------------------------------------------------------------------------------- | -------------- |
| `signature` | `string` | ✅       | ECDSA signature over the EIP-712 hash (hex-encoded with 0x prefix, 64 or 65 bytes).                                                             | maxLength: 132 |
| `message`   | `ref`    | ✅       | The EIP-712 typed data message that was signed by the wallet. Contains the fields binding an ATProto DID to an EVM address on a specific chain. |                |

##### `app.certified.link.evm#eip712Message`

The EIP-712 typed data message that was signed by the wallet. Contains the fields binding an ATProto DID to an EVM address on a specific chain.

| Property     | Type     | Required | Description                                                                                                                                                          | Comments       |
| ------------ | -------- | -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------- |
| `did`        | `string` | ✅       | The ATProto DID being linked to the EVM address.                                                                                                                     | maxLength: 256 |
| `evmAddress` | `string` | ✅       | The EVM wallet address (must match the top-level address field).                                                                                                     | maxLength: 42  |
| `chainId`    | `string` | ✅       | EVM chain ID as string (bigint serialized). Identifies which chain was used for signing; for EOA wallets the identity link applies across all EVM-compatible chains. | maxLength: 78  |
| `timestamp`  | `string` | ✅       | Unix timestamp when the attestation was created (bigint serialized).                                                                                                 | maxLength: 78  |
| `nonce`      | `string` | ✅       | Replay-protection nonce (bigint serialized).                                                                                                                         | maxLength: 78  |

---

### `app.certified.signature.defs`

**Description:** Common type definitions for cryptographic signatures attached to records, per the ATProtocol Attestation Specification. Each signature's `$type` says what it attests.

#### Defs

##### `app.certified.signature.defs#inline`

Inline attestation signature embedded directly in a record. Conforms to the ATProtocol Attestation Specification: the signed input is the 36-byte CIDv1 (dag-cbor + SHA-256) of the record with the `signatures` field removed and a temporary `$sig` metadata object (containing `$type`, `key` and the housing repository DID) inserted before canonical DAG-CBOR encoding. ECDSA with the low-S variant per BIP-0062 is required; the curve (P-256 or K-256) is determined by the multicodec prefix of the verification method's `publicKeyMultibase`.

| Property    | Type     | Required | Description                                                                                                                                                                                       | Comments       |
| ----------- | -------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------- |
| `signature` | `bytes`  | ✅       | ECDSA signature bytes (raw r,s) over the 36-byte CID of the record. Low-S variant per BIP-0062 is mandatory.                                                                                      |                |
| `key`       | `string` | ✅       | Full DID verification method reference (format: did:{method}:{identifier}#{fragment}). Identifies the signer and the specific key used; the key's multicodec prefix determines the signing curve. | maxLength: 512 |

##### `app.certified.signature.defs#createdVia`

Inline signature by the application that wrote this version of the record. It does not mean the application endorses the content. A record should carry at most one `#createdVia` signature; applications enforce this, `#list` validation does not. Signed exactly like `#inline`: `$sig` is this signature entry without its `signature` field (so `$type` and `key`), plus `repository`, the DID of the repository that holds the record.

| Property    | Type     | Required | Description                                                                                                                                                                                            | Comments       |
| ----------- | -------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------- |
| `signature` | `bytes`  | ✅       | ECDSA signature bytes (raw r,s) over the 36-byte CID of the record. Low-S variant per BIP-0062 is mandatory.                                                                                           |                |
| `key`       | `string` | ✅       | DID verification method of the application's signing key. It should be in the application's own DID document, preferably a did:web on the application's domain, so that the DID names the application. | maxLength: 512 |

---

### `app.certified.signature.proof`

**Description:** Remote attestation proof containing the CID of the content being attested.

**Key:** `tid`

#### Properties

| Property    | Type     | Required | Description                                                                                                                                                                                                                                                                                                                                                                                                                                         | Comments       |
| ----------- | -------- | -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------- |
| `cid`       | `string` | ✅       | CID of the attested content, computed per the ATProtocol Attestation Specification: encode the attested record with its `signatures` field removed and a temporary `$sig` object inserted as canonical DAG-CBOR, then SHA-256 hash to produce a 36-byte CIDv1. `$sig` is this proof record without its `cid` field (so `$type`, plus `note` and `createdAt` when set), plus `repository`: the DID of the repository that holds the attested record. |                |
| `note`      | `string` | ❌       | Optional note explaining the attestation purpose or context.                                                                                                                                                                                                                                                                                                                                                                                        | maxLength: 500 |
| `createdAt` | `string` | ❌       | Client-declared timestamp when this proof was created.                                                                                                                                                                                                                                                                                                                                                                                              |                |

---

## Type Definitions

Common type definitions used across all protocols.

### `app.certified.defs`

**Description:** Common type definitions used across certified protocols.

#### Defs

##### `app.certified.defs#did`

A Decentralized Identifier (DID) string.

| Property | Type     | Required | Description           | Comments       |
| -------- | -------- | -------- | --------------------- | -------------- |
| `did`    | `string` | ✅       | The DID string value. | maxLength: 256 |

##### `app.certified.defs#recordSubject`

A subject that is a record, referenced by AT-URI. The URI must use the DID form (not handle form) and deliberately carries no CID: it references the record's identity, not a specific version, so references made against it survive updates to the record.

| Property | Type     | Required | Description                                                                                                                                                                                                                                                                                                                |
| -------- | -------- | -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `uri`    | `string` | ✅       | AT-URI (DID form) of the record being followed. Schema validation enforces only general at-uri syntax; writers MUST supply a full record URI (did authority, collection, and rkey — not a handle authority or a partial URI), and consumers (AppView/indexer) are expected to reject or skip subjects that do not conform. |

---

### `org.hypercerts.defs`

**Description:** Common type definitions used across all Hypercerts protocols.

#### Defs

##### `org.hypercerts.defs#descriptionString`

An inline long-form description as plain text or markdown, with optional rich-text annotations.

| Property | Type     | Required | Description                                                                | Comments                               |
| -------- | -------- | -------- | -------------------------------------------------------------------------- | -------------------------------------- |
| `value`  | `string` | ✅       | The description text (plain text or markdown).                             | maxLength: 250000, maxGraphemes: 25000 |
| `facets` | `ref[]`  | ❌       | Rich text annotations for the description (mentions, URLs, hashtags, etc). |                                        |

##### `org.hypercerts.defs#uri`

Object containing a URI to external data

| Property | Type     | Required | Description          |
| -------- | -------- | -------- | -------------------- |
| `uri`    | `string` | ✅       | URI to external data |

##### `org.hypercerts.defs#smallBlob`

Object containing a blob to external data

| Property | Type   | Required | Description                        | Comments                          |
| -------- | ------ | -------- | ---------------------------------- | --------------------------------- |
| `blob`   | `blob` | ✅       | Blob to external data (up to 10MB) | maxSize: 10485760, accepts: `*/*` |

##### `org.hypercerts.defs#largeBlob`

Object containing a blob to external data

| Property | Type   | Required | Description                         | Comments                           |
| -------- | ------ | -------- | ----------------------------------- | ---------------------------------- |
| `blob`   | `blob` | ✅       | Blob to external data (up to 100MB) | maxSize: 104857600, accepts: `*/*` |

##### `org.hypercerts.defs#smallImage`

Object containing a small image

| Property | Type   | Required | Description       | Comments                                                                        |
| -------- | ------ | -------- | ----------------- | ------------------------------------------------------------------------------- |
| `image`  | `blob` | ✅       | Image (up to 5MB) | maxSize: 5242880, accepts: `image/jpeg`, `image/jpg`, `image/png`, `image/webp` |

##### `org.hypercerts.defs#smallVideo`

Object containing a small video

| Property | Type   | Required | Description        | Comments                                              |
| -------- | ------ | -------- | ------------------ | ----------------------------------------------------- |
| `video`  | `blob` | ✅       | Video (up to 20MB) | maxSize: 20971520, accepts: `video/mp4`, `video/webm` |

##### `org.hypercerts.defs#largeImage`

Object containing a large image

| Property | Type   | Required | Description        | Comments                                                                         |
| -------- | ------ | -------- | ------------------ | -------------------------------------------------------------------------------- |
| `image`  | `blob` | ✅       | Image (up to 10MB) | maxSize: 10485760, accepts: `image/jpeg`, `image/jpg`, `image/png`, `image/webp` |

---

## External Lexicons

External lexicons from other protocols and systems.

### `app.bsky.richtext.facet`

**Description:** Annotation of a sub-string within rich text.

#### Properties

| Property   | Type      | Required | Description                                                                                                                                                                                                                                                                                                                                                |
| ---------- | --------- | -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `index`    | `ref`     | ✅       | Specifies the sub-string range a facet feature applies to. Start index is inclusive, end index is exclusive. Indices are zero-indexed, counting bytes of the UTF-8 encoded text. NOTE: some languages, like Javascript, use UTF-16 or Unicode codepoints for string slice indexing; in these languages, convert to byte arrays before working with facets. |
| `features` | `union[]` | ✅       |                                                                                                                                                                                                                                                                                                                                                            |

#### Defs

##### `app.bsky.richtext.facet#mention`

Facet feature for mention of another account. The text is usually a handle, including a '@' prefix, but the facet reference is a DID.

| Property | Type     | Required | Description |
| -------- | -------- | -------- | ----------- |
| `did`    | `string` | ✅       |             |

##### `app.bsky.richtext.facet#link`

Facet feature for a URL. The text URL may have been simplified or truncated, but the facet reference should be a complete URL.

| Property | Type     | Required | Description |
| -------- | -------- | -------- | ----------- |
| `uri`    | `string` | ✅       |             |

##### `app.bsky.richtext.facet#tag`

Facet feature for a hashtag. The text usually includes a '#' prefix, but the facet reference should not (except in the case of 'double hash tags').

| Property | Type     | Required | Description | Comments                         |
| -------- | -------- | -------- | ----------- | -------------------------------- |
| `tag`    | `string` | ✅       |             | maxLength: 640, maxGraphemes: 64 |

##### `app.bsky.richtext.facet#byteSlice`

Specifies the sub-string range a facet feature applies to. Start index is inclusive, end index is exclusive. Indices are zero-indexed, counting bytes of the UTF-8 encoded text. NOTE: some languages, like Javascript, use UTF-16 or Unicode codepoints for string slice indexing; in these languages, convert to byte arrays before working with facets.

| Property    | Type      | Required | Description | Comments   |
| ----------- | --------- | -------- | ----------- | ---------- |
| `byteStart` | `integer` | ✅       |             | minimum: 0 |
| `byteEnd`   | `integer` | ✅       |             | minimum: 0 |

---

### `com.atproto.repo.strongRef`

#### Properties

| Property | Type     | Required | Description |
| -------- | -------- | -------- | ----------- |
| `uri`    | `string` | ✅       |             |
| `cid`    | `string` | ✅       |             |

---

### `org.hyperboards.authWrite`

**Title:** Manage your Hyperboards data

**Detail:** Create, edit, and delete your Hyperboards records (board configurations and display profiles).

**Resource:** `repo`

**Collections:** `org.hyperboards.board`, `org.hyperboards.displayProfile`

**Actions:** `create`, `update`, `delete`

---

### `org.hyperboards.board`

**Description:** Configuration record for a hyperboard, wrapping an underlying activity or collection with visual presentation settings. Stored in the creator's PDS.

**Key:** `tid`

#### Properties

| Property             | Type     | Required | Description                                                                                        | Comments        |
| -------------------- | -------- | -------- | -------------------------------------------------------------------------------------------------- | --------------- |
| `subject`            | `ref`    | ✅       | Reference to the org.hypercerts.claim.activity or org.hypercerts.collection this board visualizes. |                 |
| `config`             | `ref`    | ❌       | Visual configuration for a hyperboard's background, colors, and layout.                            |                 |
| `contributorConfigs` | `ref[]`  | ❌       | Per-contributor configuration entries for this board.                                              | maxLength: 1000 |
| `createdAt`          | `string` | ✅       | Client-declared timestamp when this record was originally created.                                 |                 |
| `signatures`         | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                              |                 |

#### Defs

##### `org.hyperboards.board#boardConfig`

Visual configuration for a hyperboard's background, colors, and layout.

| Property              | Type      | Required | Description                                                           | Comments                                          |
| --------------------- | --------- | -------- | --------------------------------------------------------------------- | ------------------------------------------------- |
| `backgroundType`      | `string`  | ❌       | Type of background content.                                           | maxLength: 10, Known values: `image`, `iframe`    |
| `backgroundImage`     | `union`   | ❌       | Background image as a URI or image blob.                              |                                                   |
| `backgroundIframeUrl` | `string`  | ❌       | URI of the background iframe.                                         | maxLength: 2048                                   |
| `backgroundGrayscale` | `boolean` | ❌       | Whether the background is rendered in grayscale. Default: true.       |                                                   |
| `backgroundOpacity`   | `integer` | ❌       | Background opacity as a percentage (0–100).                           | minimum: 0, maximum: 100                          |
| `backgroundColor`     | `string`  | ❌       | Background color as a hex string (e.g. '#ffffff').                    | maxLength: 20                                     |
| `borderColor`         | `string`  | ❌       | Border color as a hex string (e.g. '#000000').                        | maxLength: 20                                     |
| `grayscaleImages`     | `boolean` | ❌       | Whether contributor images are rendered in grayscale. Default: false. |                                                   |
| `imageShape`          | `string`  | ❌       | Shape used to crop contributor images on this board.                  | maxLength: 20, Known values: `circular`, `square` |
| `aspectRatio`         | `string`  | ❌       | Display aspect ratio of the board.                                    | maxLength: 10, Known values: `16:9`, `4:3`, `1:1` |

##### `org.hyperboards.board#contributorConfig`

Configuration for a specific contributor within a board. Values serve as fallbacks when the contributor has not defined them on their profile. It can also be used to override contributor settings on this board without changing their global profile.

| Property         | Type      | Required | Description                                                                                                                                                                                                            | Comments                         |
| ---------------- | --------- | -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------- |
| `contributor`    | `union`   | ✅       | Identifies the contributor being styled. A strong reference to an org.hypercerts.claim.contributorInformation record, or a contributorIdentity (DID or identifier string) for contributors without a dedicated record. |                                  |
| `override`       | `boolean` | ❌       | When true, these values take precedence over the contributor's own profile and display settings. When false or omitted, they are only used as fallbacks if the contributor has not set their own settings.             |                                  |
| `displayName`    | `string`  | ❌       | Display name for this contributor on this board.                                                                                                                                                                       | maxLength: 640, maxGraphemes: 64 |
| `image`          | `union`   | ❌       | Avatar or face image for this contributor on this board, as a URI or image blob.                                                                                                                                       |                                  |
| `video`          | `union`   | ❌       | Video for this contributor, as a URI (embed/direct link) or uploaded video blob.                                                                                                                                       |                                  |
| `hoverImage`     | `union`   | ❌       | Image overlay shown when hovering over this contributor, as a URI or image blob.                                                                                                                                       |                                  |
| `hoverIframeUrl` | `string`  | ❌       | Iframe overlay shown when hovering over this contributor.                                                                                                                                                              | maxLength: 2048                  |
| `url`            | `string`  | ❌       | Click-through link URL for this contributor.                                                                                                                                                                           | maxLength: 2048                  |

---

### `org.hyperboards.displayProfile`

**Description:** User-declared visual presentation defaults for how a contributor appears on hyperboards. Stored in the contributor's own PDS and reusable across multiple boards.

**Key:** `literal:self`

#### Properties

| Property         | Type     | Required | Description                                                                                     | Comments                         |
| ---------------- | -------- | -------- | ----------------------------------------------------------------------------------------------- | -------------------------------- |
| `displayName`    | `string` | ❌       | Display name override for this user on hyperboards.                                             | maxLength: 640, maxGraphemes: 64 |
| `image`          | `union`  | ❌       | Avatar or face image override for this user on hyperboards, as a URI or image blob.             |                                  |
| `video`          | `union`  | ❌       | Default video for this user across boards, as a URI (embed/direct link) or uploaded video blob. |                                  |
| `hoverImage`     | `union`  | ❌       | Default hover image for this user across boards, as a URI or image blob.                        |                                  |
| `hoverIframeUrl` | `string` | ❌       | Default hover iframe URL for this user across boards.                                           | maxLength: 2048                  |
| `url`            | `string` | ❌       | Default click-through link URL for this user across boards.                                     | maxLength: 2048                  |
| `createdAt`      | `string` | ✅       | Client-declared timestamp when this record was originally created.                              |                                  |
| `signatures`     | `ref`    | ❌       | Optional cryptographic signatures attesting to this record's content.                           |                                  |

---

### `pub.leaflet.blocks.blockquote`

#### Properties

| Property    | Type     | Required | Description |
| ----------- | -------- | -------- | ----------- |
| `plaintext` | `string` | ✅       |             |
| `facets`    | `ref[]`  | ❌       |             |

---

### `pub.leaflet.blocks.bskyPost`

#### Properties

| Property     | Type     | Required | Description |
| ------------ | -------- | -------- | ----------- |
| `postRef`    | `ref`    | ✅       |             |
| `clientHost` | `string` | ❌       |             |

---

### `pub.leaflet.blocks.button`

#### Properties

| Property | Type     | Required | Description |
| -------- | -------- | -------- | ----------- |
| `text`   | `string` | ✅       |             |
| `url`    | `string` | ✅       |             |

---

### `pub.leaflet.blocks.code`

#### Properties

| Property                  | Type     | Required | Description |
| ------------------------- | -------- | -------- | ----------- |
| `plaintext`               | `string` | ✅       |             |
| `language`                | `string` | ❌       |             |
| `syntaxHighlightingTheme` | `string` | ❌       |             |

---

### `pub.leaflet.blocks.header`

#### Properties

| Property    | Type      | Required | Description | Comments               |
| ----------- | --------- | -------- | ----------- | ---------------------- |
| `level`     | `integer` | ❌       |             | minimum: 1, maximum: 6 |
| `plaintext` | `string`  | ✅       |             |                        |
| `facets`    | `ref[]`   | ❌       |             |                        |

---

### `pub.leaflet.blocks.horizontalRule`

#### Properties

---

### `pub.leaflet.blocks.html`

#### Properties

| Property      | Type      | Required | Description                                                     | Comments                   |
| ------------- | --------- | -------- | --------------------------------------------------------------- | -------------------------- |
| `html`        | `string`  | ✅       | Inline HTML rendered via a sandboxed iframe's srcdoc attribute. |                            |
| `height`      | `integer` | ❌       |                                                                 | minimum: 16, maximum: 1600 |
| `aspectRatio` | `ref`     | ❌       |                                                                 |                            |

#### Defs

##### `pub.leaflet.blocks.html#aspectRatio`

| Property | Type      | Required | Description |
| -------- | --------- | -------- | ----------- |
| `width`  | `integer` | ✅       |             |
| `height` | `integer` | ✅       |             |

---

### `pub.leaflet.blocks.iframe`

#### Properties

| Property      | Type      | Required | Description                                                                                                                          | Comments                   |
| ------------- | --------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------ | -------------------------- |
| `url`         | `string`  | ❌       |                                                                                                                                      |                            |
| `html`        | `string`  | ❌       | DEPRECATED — use pub.leaflet.blocks.html instead. Inline HTML rendered via the iframe's srcdoc attribute. Takes precedence over url. |                            |
| `height`      | `integer` | ❌       |                                                                                                                                      | minimum: 16, maximum: 1600 |
| `aspectRatio` | `ref`     | ❌       |                                                                                                                                      |                            |

#### Defs

##### `pub.leaflet.blocks.iframe#aspectRatio`

| Property | Type      | Required | Description |
| -------- | --------- | -------- | ----------- |
| `width`  | `integer` | ✅       |             |
| `height` | `integer` | ✅       |             |

---

### `pub.leaflet.blocks.image`

#### Properties

| Property      | Type      | Required | Description                                                                           | Comments                             |
| ------------- | --------- | -------- | ------------------------------------------------------------------------------------- | ------------------------------------ |
| `image`       | `blob`    | ✅       |                                                                                       | maxSize: 1000000, accepts: `image/*` |
| `alt`         | `string`  | ❌       | Alt text description of the image, for accessibility.                                 |                                      |
| `aspectRatio` | `ref`     | ✅       |                                                                                       |                                      |
| `fullBleed`   | `boolean` | ❌       | Whether the image should extend to the full width of the container, ignoring padding. |                                      |
| `width`       | `integer` | ❌       | Display width of the image in pixels, capped at the page width.                       |                                      |

#### Defs

##### `pub.leaflet.blocks.image#aspectRatio`

| Property | Type      | Required | Description |
| -------- | --------- | -------- | ----------- |
| `width`  | `integer` | ✅       |             |
| `height` | `integer` | ✅       |             |

---

### `pub.leaflet.blocks.imageGallery`

#### Properties

| Property   | Type      | Required | Description                                                         | Comments                                  |
| ---------- | --------- | -------- | ------------------------------------------------------------------- | ----------------------------------------- |
| `gap`      | `integer` | ❌       | Gap between images in pixels.                                       |                                           |
| `format`   | `string`  | ❌       |                                                                     | Known values: `grid`, `carousel`, `strip` |
| `images`   | `ref[]`   | ✅       |                                                                     |                                           |
| `maxWidth` | `integer` | ❌       | Max width per image in grid view (px); drives how many columns fit. |                                           |

#### Defs

##### `pub.leaflet.blocks.imageGallery#image`

| Property      | Type     | Required | Description                                           | Comments                             |
| ------------- | -------- | -------- | ----------------------------------------------------- | ------------------------------------ |
| `alt`         | `string` | ❌       | Alt text description of the image, for accessibility. |                                      |
| `image`       | `blob`   | ✅       |                                                       | maxSize: 1000000, accepts: `image/*` |
| `aspectRatio` | `ref`    | ✅       |                                                       |                                      |

##### `pub.leaflet.blocks.imageGallery#aspectRatio`

| Property | Type      | Required | Description |
| -------- | --------- | -------- | ----------- |
| `width`  | `integer` | ✅       |             |
| `height` | `integer` | ✅       |             |

---

### `pub.leaflet.blocks.math`

#### Properties

| Property | Type     | Required | Description |
| -------- | -------- | -------- | ----------- |
| `tex`    | `string` | ✅       |             |

---

### `pub.leaflet.blocks.membersOnlyDelimiter`

**Description:** Marks where members-only content begins; blocks after this delimiter are only served to readers with an active paid membership.

#### Properties

---

### `pub.leaflet.blocks.orderedList`

#### Properties

| Property     | Type      | Required | Description                                                                |
| ------------ | --------- | -------- | -------------------------------------------------------------------------- |
| `startIndex` | `integer` | ❌       | The starting number for this ordered list. Defaults to 1 if not specified. |
| `children`   | `ref[]`   | ✅       |                                                                            |

#### Defs

##### `pub.leaflet.blocks.orderedList#listItem`

| Property                | Type      | Required | Description                                                                                                               |
| ----------------------- | --------- | -------- | ------------------------------------------------------------------------------------------------------------------------- |
| `checked`               | `boolean` | ❌       | If present, this item is a checklist item. true = checked, false = unchecked. If absent, this is a normal list item.      |
| `content`               | `union`   | ✅       |                                                                                                                           |
| `children`              | `ref[]`   | ❌       | Nested ordered list items. Mutually exclusive with unorderedListChildren; if both are present, children takes precedence. |
| `unorderedListChildren` | `ref`     | ❌       | A nested unordered list. Mutually exclusive with children; if both are present, children takes precedence.                |

---

### `pub.leaflet.blocks.page`

#### Properties

| Property | Type     | Required | Description |
| -------- | -------- | -------- | ----------- |
| `id`     | `string` | ✅       |             |

---

### `pub.leaflet.blocks.poll`

#### Properties

| Property  | Type  | Required | Description |
| --------- | ----- | -------- | ----------- |
| `pollRef` | `ref` | ✅       |             |

---

### `pub.leaflet.blocks.postsList`

#### Properties

| Property             | Type       | Required | Description                   | Comments                        |
| -------------------- | ---------- | -------- | ----------------------------- | ------------------------------- |
| `view`               | `string`   | ❌       |                               | Known values: `small`, `medium` |
| `limit`              | `integer`  | ❌       | Show at most this many posts. | minimum: 1                      |
| `filterByTags`       | `string[]` | ❌       |                               |                                 |
| `highlightFirstPost` | `boolean`  | ❌       |                               |                                 |

---

### `pub.leaflet.blocks.signup`

**Description:** A subscribe/signup form for the publication. Renders the publication's subscribe form; carries no configurable data.

#### Properties

---

### `pub.leaflet.blocks.standardSitePost`

#### Properties

| Property               | Type      | Required | Description | Comments                                 |
| ---------------------- | --------- | -------- | ----------- | ---------------------------------------- |
| `cid`                  | `string`  | ❌       |             |                                          |
| `uri`                  | `string`  | ✅       |             |                                          |
| `size`                 | `string`  | ❌       |             | Known values: `large`, `medium`, `small` |
| `showPublicationTheme` | `boolean` | ❌       |             |                                          |

---

### `pub.leaflet.blocks.standardSitePublication`

#### Properties

| Property               | Type      | Required | Description |
| ---------------------- | --------- | -------- | ----------- |
| `cid`                  | `string`  | ❌       |             |
| `uri`                  | `string`  | ✅       |             |
| `showPublicationTheme` | `boolean` | ❌       |             |

---

### `pub.leaflet.blocks.text`

#### Properties

| Property    | Type     | Required | Description |
| ----------- | -------- | -------- | ----------- |
| `plaintext` | `string` | ✅       |             |
| `textSize`  | `string` | ❌       |             |
| `facets`    | `ref[]`  | ❌       |             |

---

### `pub.leaflet.blocks.unorderedList`

#### Properties

| Property   | Type    | Required | Description |
| ---------- | ------- | -------- | ----------- |
| `children` | `ref[]` | ✅       |             |

#### Defs

##### `pub.leaflet.blocks.unorderedList#listItem`

| Property              | Type      | Required | Description                                                                                                               |
| --------------------- | --------- | -------- | ------------------------------------------------------------------------------------------------------------------------- |
| `checked`             | `boolean` | ❌       | If present, this item is a checklist item. true = checked, false = unchecked. If absent, this is a normal list item.      |
| `content`             | `union`   | ✅       |                                                                                                                           |
| `children`            | `ref[]`   | ❌       | Nested unordered list items. Mutually exclusive with orderedListChildren; if both are present, children takes precedence. |
| `orderedListChildren` | `ref`     | ❌       | Nested ordered list items. Mutually exclusive with children; if both are present, children takes precedence.              |

---

### `pub.leaflet.blocks.website`

#### Properties

| Property       | Type     | Required | Description | Comments                             |
| -------------- | -------- | -------- | ----------- | ------------------------------------ |
| `previewImage` | `blob`   | ❌       |             | maxSize: 1000000, accepts: `image/*` |
| `title`        | `string` | ❌       |             |                                      |
| `description`  | `string` | ❌       |             |                                      |
| `src`          | `string` | ✅       |             |                                      |

---

### `pub.leaflet.pages.linearDocument`

#### Properties

| Property | Type     | Required | Description |
| -------- | -------- | -------- | ----------- |
| `id`     | `string` | ❌       |             |
| `blocks` | `ref[]`  | ✅       |             |

#### Defs

##### `pub.leaflet.pages.linearDocument#block`

| Property    | Type     | Required | Description | Comments                                                                                   |
| ----------- | -------- | -------- | ----------- | ------------------------------------------------------------------------------------------ |
| `block`     | `union`  | ✅       |             |                                                                                            |
| `alignment` | `string` | ❌       |             | Known values: `#textAlignLeft`, `#textAlignCenter`, `#textAlignRight`, `#textAlignJustify` |

##### `pub.leaflet.pages.linearDocument#quote`

| Property | Type  | Required | Description |
| -------- | ----- | -------- | ----------- |
| `start`  | `ref` | ✅       |             |
| `end`    | `ref` | ✅       |             |

##### `pub.leaflet.pages.linearDocument#position`

| Property | Type        | Required | Description |
| -------- | ----------- | -------- | ----------- |
| `block`  | `integer[]` | ✅       |             |
| `offset` | `integer`   | ✅       |             |

---

### `pub.leaflet.richtext.facet`

**Description:** Annotation of a sub-string within rich text.

#### Properties

| Property   | Type      | Required | Description                                                                                                                                                                                                                                                                                                                                                |
| ---------- | --------- | -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `index`    | `ref`     | ✅       | Specifies the sub-string range a facet feature applies to. Start index is inclusive, end index is exclusive. Indices are zero-indexed, counting bytes of the UTF-8 encoded text. NOTE: some languages, like Javascript, use UTF-16 or Unicode codepoints for string slice indexing; in these languages, convert to byte arrays before working with facets. |
| `features` | `union[]` | ✅       |                                                                                                                                                                                                                                                                                                                                                            |

#### Defs

##### `pub.leaflet.richtext.facet#byteSlice`

Specifies the sub-string range a facet feature applies to. Start index is inclusive, end index is exclusive. Indices are zero-indexed, counting bytes of the UTF-8 encoded text. NOTE: some languages, like Javascript, use UTF-16 or Unicode codepoints for string slice indexing; in these languages, convert to byte arrays before working with facets.

| Property    | Type      | Required | Description | Comments   |
| ----------- | --------- | -------- | ----------- | ---------- |
| `byteStart` | `integer` | ✅       |             | minimum: 0 |
| `byteEnd`   | `integer` | ✅       |             | minimum: 0 |

##### `pub.leaflet.richtext.facet#link`

Facet feature for a URL. The text URL may have been simplified or truncated, but the facet reference should be a complete URL.

| Property | Type     | Required | Description |
| -------- | -------- | -------- | ----------- |
| `uri`    | `string` | ✅       |             |

##### `pub.leaflet.richtext.facet#didMention`

Facet feature for mentioning a did.

| Property | Type     | Required | Description |
| -------- | -------- | -------- | ----------- |
| `did`    | `string` | ✅       |             |

##### `pub.leaflet.richtext.facet#atMention`

Facet feature for mentioning an AT URI.

| Property | Type     | Required | Description |
| -------- | -------- | -------- | ----------- |
| `atURI`  | `string` | ✅       |             |
| `href`   | `string` | ❌       |             |

##### `pub.leaflet.richtext.facet#code`

Facet feature for inline code.

##### `pub.leaflet.richtext.facet#highlight`

Facet feature for highlighted text.

| Property | Type    | Required | Description |
| -------- | ------- | -------- | ----------- |
| `color`  | `union` | ❌       |             |

##### `pub.leaflet.richtext.facet#underline`

Facet feature for underline markup

##### `pub.leaflet.richtext.facet#strikethrough`

Facet feature for strikethrough markup

##### `pub.leaflet.richtext.facet#id`

Facet feature for an identifier. Used for linking to a segment

| Property | Type     | Required | Description |
| -------- | -------- | -------- | ----------- |
| `id`     | `string` | ❌       |             |

##### `pub.leaflet.richtext.facet#bold`

Facet feature for bold text

##### `pub.leaflet.richtext.facet#italic`

Facet feature for italic text

##### `pub.leaflet.richtext.facet#footnote`

Facet feature for a footnote reference

| Property           | Type     | Required | Description |
| ------------------ | -------- | -------- | ----------- |
| `footnoteId`       | `string` | ✅       |             |
| `contentPlaintext` | `string` | ✅       |             |
| `contentFacets`    | `ref[]`  | ❌       |             |

---

### `pub.leaflet.theme.color`

#### Defs

##### `pub.leaflet.theme.color#rgb`

| Property | Type      | Required | Description | Comments                 |
| -------- | --------- | -------- | ----------- | ------------------------ |
| `b`      | `integer` | ✅       |             | minimum: 0, maximum: 255 |
| `g`      | `integer` | ✅       |             | minimum: 0, maximum: 255 |
| `r`      | `integer` | ✅       |             | minimum: 0, maximum: 255 |

##### `pub.leaflet.theme.color#rgba`

| Property | Type      | Required | Description | Comments                 |
| -------- | --------- | -------- | ----------- | ------------------------ |
| `a`      | `integer` | ✅       |             | minimum: 0, maximum: 100 |
| `b`      | `integer` | ✅       |             | minimum: 0, maximum: 255 |
| `g`      | `integer` | ✅       |             | minimum: 0, maximum: 255 |
| `r`      | `integer` | ✅       |             | minimum: 0, maximum: 255 |

---

## Notes

- All timestamps use the `datetime` format (ISO 8601)
- Strong references (`com.atproto.repo.strongRef`) include both the URI and CID of the referenced record
- Union types allow multiple possible formats (e.g., URI or blob)
- Array items may have constraints like `maxLength` to limit the number of elements
- String fields may have both `maxLength` (bytes) and `maxGraphemes` (Unicode grapheme clusters) constraints
